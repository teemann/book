int http_get_requested_file(const char* http, char* dst, int dst_size);
int http_get_response_header(int code, int len, char* dst, int dst_size);
